var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/node_modules_next_dist_0shnk67-kqyxl._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_lxmyse._.js")
R.c("server/chunks/_042sj8jnzufkl._.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_1-lsc8hsfphob.js")
R.m(72755)
module.exports=R.m(72755).exports
