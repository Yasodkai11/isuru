var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image/route.js")
R.c("server/chunks/[root-of-the-server]__1ld1_inb8f9k9._.js")
R.c("server/chunks/_0zlfhp9mhvm9z._.js")
R.c("server/chunks/node_modules_next_dist_0shnk67-kqyxl._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_lxmyse._.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_route_actions_1n32_cshpygg5.js")
R.m(9191)
module.exports=R.m(9191).exports
