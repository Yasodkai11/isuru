globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/cMeGd64x6gNxJ_R-nchM6/_buildManifest.js",
    "static/cMeGd64x6gNxJ_R-nchM6/_ssgManifest.js",
    "static/cMeGd64x6gNxJ_R-nchM6/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ckvzn7sfprko.js",
    "static/chunks/13ebhwe8d-mme.js",
    "static/chunks/3rrvct_pzfm_s.js",
    "static/chunks/3847xtulbb6i8.js",
    "static/chunks/2bzlqb104tejm.js",
    "static/chunks/turbopack-2c3mg3r-05n1w.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/login/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/register/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/about/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/account/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/cart/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/certificates/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/checkout/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/contact/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/gems/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/gems/[slug]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/gems/category/[category]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(shop)/wholesale/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/categories/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/customers/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/enquiries/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/login/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/media/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/orders/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/products/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/seo/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/staff/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/13ebhwe8d-mme.js",
        "static/chunks/3rrvct_pzfm_s.js",
        "static/chunks/3847xtulbb6i8.js",
        "static/chunks/2bzlqb104tejm.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
