var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/node_modules_next_dist_16uekqf-emgzs._.js")
R.c("server/chunks/node_modules_next_dist_0shnk67-kqyxl._.js")
R.c("server/chunks/[root-of-the-server]__1r01cl_lxmyse._.js")
R.c("server/chunks/_1rbd81eryasrk._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_15vc_89wprgh5.js")
R.m(77067)
module.exports=R.m(77067).exports
