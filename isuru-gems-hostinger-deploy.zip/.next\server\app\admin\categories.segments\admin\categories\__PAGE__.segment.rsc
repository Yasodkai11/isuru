1:"$Sreact.fragment"
2:"/_next/static/chunks/0v9xatz6t-6q9.js"
3:"/_next/static/chunks/0_425ujkk2ty8.js"
4:"/_next/static/chunks/0_onttqxinsi2.js"
5:"/_next/static/chunks/0839fnx-w1g-f.js"
6:I[74377,["$2","$3","$4","$5"],"ScrollProgress"]
7:I[45872,["$2","$3","$4","$5"],"Header"]
8:"/_next/static/chunks/42onvq6nokjl2.js"
9:I[39756,["$8"],"default"]
a:I[37457,["$8"],"default"]
b:I[22016,["$2","$3","$4","$5"],""]
c:I[44604,["$2","$3","$4","$5"],"Footer"]
d:I[92482,["$2","$3","$4","$5"],"CartSheet"]
11:"/_next/static/chunks/0ku_widhbcvgo.js"
12:"AdminLayoutShell"
13:I[64364,["$2","$3","$4","$5","$11"],"$12"]
19:I[47257,["$8"],"ClientPageRoot"]
1a:"/_next/static/chunks/040mzzqpx9hh8.js"
1b:I[69888,["$2","$3","$4","$5","$11","$1a"],"default"]
1e:I[97367,["$8"],"OutletBoundary"]
1f:"$Sreact.suspense"
22:"ViewportBoundary"
23:I[97367,["$8"],"$22"]
24:"MetadataBoundary"
25:I[97367,["$8"],"$24"]
:HL["/_next/static/chunks/1jlp_jc9gmzo4.css","style"]
:HL["/_next/static/chunks/18-oxasnoxfck.css","style"]
f:X
17:X
17:C
18:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$1","c",{"children":[["$","$L19",null,{"Component":"$1b","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@1c","$@1d"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/040mzzqpx9hh8.js","async":true}]],["$","$L1e",null,{"children":["$","$1f",null,{"name":"Next.MetadataOutlet","children":"$@20"}]}]]}],"p":"$@21","v":null,"s":"$f"}}]]
15:[["children",{"s":"categories","h":96,"d":{"r":["$","$1","c",{"children":[null,["$","$L9",null,{"parallelRouterKey":"children","template":["$","$La",null,{}]}]]}],"p":"$@16","v":"$17","s":"$f"},"c":"$Q18"}]]
10:[["children",{"s":"admin","h":96,"d":{"r":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/0ku_widhbcvgo.js","async":true}]],["$","$L13",null,{"children":["$","$L9",null,{"parallelRouterKey":"children","template":["$","$La",null,{}]}]}]]}],"p":"$@14","v":null,"s":"$f"},"c":"$Q15"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1jlp_jc9gmzo4.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/18-oxasnoxfck.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/0v9xatz6t-6q9.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0_425ujkk2ty8.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/0_onttqxinsi2.js","async":true}],["$","script","script-3",{"src":"/_next/static/chunks/0839fnx-w1g-f.js","async":true}]],["$","html",null,{"lang":"en","className":"H6XBiG_variable f5oAPG_variable","children":["$","body",null,{"className":"min-h-screen flex flex-col bg-[#FAF6EE] text-[#2B2B2B] antialiased selection:bg-[#B8924A]/20 selection:text-[#5E0F1E]","children":[["$","$L6",null,{}],["$","$L7",null,{}],["$","main",null,{"className":"flex-1","children":["$","$L9",null,{"parallelRouterKey":"children","template":["$","$La",null,{}],"notFound":[["$","div",null,{"className":"py-24 bg-[#FAF6EE] min-h-[70vh] flex items-center justify-center text-center","children":["$","div",null,{"className":"max-w-md mx-auto px-4 space-y-6","children":[["$","span",null,{"className":"text-[10px] uppercase tracking-[0.3em] text-[#B8924A] font-semibold block","children":"Error 404 • Island Archive"}],["$","h1",null,{"className":"font-serif text-4xl text-[#5E0F1E] font-normal","children":"Specimen Not Found"}],["$","p",null,{"className":"text-sm text-[#2B2B2B]/75 leading-relaxed","children":"The gemstone archive or page you are seeking may have been placed in private museum reserve or re-cataloged."}],["$","div",null,{"className":"relative flex items-center justify-center my-10 my-6","children":[["$","div",null,{"className":"flex-grow h-[1px] bg-gradient-to-r from-transparent via-[#B8924A]/50 to-[#B8924A]/70"}],["$","div",null,{"className":"mx-4 flex items-center space-x-1.5 text-[#B8924A]","children":[["$","span",null,{"className":"inline-block w-1 h-1 rotate-45 bg-[#B8924A]"}],["$","span",null,{"className":"inline-block w-2 h-2 rotate-45 border border-[#B8924A] bg-[#FAF6EE]"}],["$","span",null,{"className":"inline-block w-1 h-1 rotate-45 bg-[#B8924A]"}]]}],["$","div",null,{"className":"flex-grow h-[1px] bg-gradient-to-l from-transparent via-[#B8924A]/50 to-[#B8924A]/70"}]]}],["$","div",null,{"children":["$","$Lb",null,{"href":"/gems","className":"inline-flex items-center justify-center bg-[#5E0F1E] text-[#FAF6EE] px-8 py-3.5 text-xs uppercase tracking-[0.2em] font-medium hover:bg-[#420A15] transition-colors","children":"Explore Active Vault"}]}]]}]}],[]]}]}],["$","$Lc",null,{}],["$","$Ld",null,{}]]}]}]]}],"p":"$@e","v":null,"s":"$f"},"c":"$Q10"},"h":{"r":["$","$1","h",{"children":[null,["$","$L23",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L25",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$1f",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Admin Vault Console | Isuru Gems Ceylon | Isuru Gems Ceylon"}],["$","meta","1",{"name":"description","content":"Executive gemstone inventory, acquisition workflow, and client concierge management console."}],["$","meta","2",{"name":"author","content":"Isuru Gems Ceylon"}],["$","meta","3",{"name":"keywords","content":"Ceylon Sapphires,Ratnapura Gems,Padparadscha Sapphire,Royal Blue Sapphire Sri Lanka,Unheated Ceylon Sapphire,Natural Gemstones Sri Lanka,National Gem and Jewellery Authority NGJA"}],["$","meta","4",{"name":"robots","content":"noindex, nofollow"}],["$","meta","5",{"property":"og:title","content":"Isuru Gems | Natural Ceylon Sapphires & Fine Island Gemstones"}],["$","meta","6",{"property":"og:description","content":"Ethically mined, unheated certified Ceylon gemstones direct from Ratnapura."}],["$","meta","7",{"property":"og:site_name","content":"Isuru Gems"}],["$","meta","8",{"property":"og:locale","content":"en_US"}],["$","meta","9",{"property":"og:image","content":"https://isurugems.com/opengraph-image?603d617292a100a2"}],["$","meta","10",{"property":"og:image:type","content":"image/png"}],["$","meta","11",{"property":"og:image:width","content":"1200"}],"$L26","$L27","$L28","$L29","$L2a","$L2b","$L2c","$L2d","$L2e","$L2f","$L30","$L31","$L32","$L33","$L34","$L35","$L36"]}]}],null]}],"$L37"]}],"p":"$@38","v":null,"s":"$f"}},"a":"$@39","u":"$@3a","b":"cMeGd64x6gNxJ_R-nchM6"}
3b:I[27201,["$8"],"IconMark"]
1c:{}
1d:"$18:0:1:d:r:props:children:0:props:serverProvidedParams:params"
20:null
26:["$","meta","12",{"property":"og:image:height","content":"630"}]
27:["$","meta","13",{"property":"og:image:alt","content":"Isuru Gems Ceylon | Fine Natural Sapphires & Island Gemstones"}]
28:["$","meta","14",{"property":"og:type","content":"website"}]
29:["$","meta","15",{"name":"twitter:card","content":"summary_large_image"}]
2a:["$","meta","16",{"name":"twitter:title","content":"Isuru Gems | Natural Ceylon Sapphires & Fine Island Gemstones"}]
2b:["$","meta","17",{"name":"twitter:description","content":"Ethically mined, unheated certified Ceylon gemstones direct from Ratnapura."}]
2c:["$","meta","18",{"name":"twitter:image","content":"https://isurugems.com/opengraph-image?603d617292a100a2"}]
2d:["$","meta","19",{"name":"twitter:image:alt","content":"Isuru Gems Ceylon | Fine Natural Sapphires & Island Gemstones"}]
2e:["$","meta","20",{"name":"twitter:image:type","content":"image/png"}]
2f:["$","meta","21",{"name":"twitter:image:width","content":"1200"}]
30:["$","meta","22",{"name":"twitter:image:height","content":"630"}]
31:["$","link","23",{"rel":"shortcut icon","href":"/favicon.ico"}]
32:["$","link","24",{"rel":"icon","href":"/favicon.ico?favicon.2iy78bpko6gzz.ico","sizes":"48x48","type":"image/x-icon"}]
33:["$","link","25",{"rel":"icon","href":"/icon.png","type":"image/png"}]
34:["$","link","26",{"rel":"icon","href":"/favicon.ico"}]
35:["$","link","27",{"rel":"apple-touch-icon","href":"/apple-icon.png","sizes":"180x180","type":"image/png"}]
36:["$","$L3b","28",{}]
37:["$","meta",null,{"name":"next-size-adjust","content":""}]
f:300
3a:true
f:C
39:0
16:"$undefined"
14:"$undefined"
e:"$undefined"
38:"$undefined"
21:"$undefined"
