module.exports=[8396,a=>{"use strict";var b=a.i(5050);let c=(0,b.createServerReference)("0000cd42ca2ec29cd08636523e2962da9cda17209f",b.callServer,void 0,b.findSourceMapURL,"getAdminInquiriesAction");a.s(["f",0,c])}];

//# sourceMappingURL=src_actions_data_916660_0ne78k7q8eyfp._.js.map