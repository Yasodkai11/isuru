import { z } from "zod";

export const loginSchema = z
  .object({
    identifier: z.string().min(2, "Please enter your username or email address").optional(),
    email: z.string().optional(),
    password: z.string().min(6, "Password must be at least 6 characters long"),
  })
  .refine((data) => Boolean(data.identifier || data.email), {
    message: "Username or email address is required",
    path: ["identifier"],
  });

export const registerSchema = z.object({
  fullName: z.string().min(2, "Full name must be at least 2 characters long"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters long"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
